export { ContractorReducer } from './contractors.slice'

export { MenueReducer } from './menue.slice'