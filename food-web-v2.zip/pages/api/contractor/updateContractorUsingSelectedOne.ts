import prisma from "@/lib/prismaclient";
import { ErrorResponse, SuccessResponse } from "@/utils/customeresponses";
import { NextApiRequest, NextApiResponse } from "next";
export interface UpdateContractorBySelectedOneDTO {
    contractorID: string
    categoryID: string
}
const handler = async (req: NextApiRequest, res: NextApiResponse) => {
    try {
        const { categoryID, contractorID } = req.body as UpdateContractorBySelectedOneDTO

        const categoryExisist = await prisma.categories.findFirst({
            where: {
                id: categoryID
            }
        })

        // console.log('not found', categoryExisist);
        

        if(categoryExisist?.contractorId === null) {
            await prisma.categories.update({
                where: {
                    id: categoryID
                },
                data: {
                    contractorId: contractorID
                }
            })
        } else {
            const contractorExisist = await prisma.contractor.findFirst({
                where: {
                    id: contractorID
                }
            })

            console.log('contractorExisist', contractorExisist);
            

            if(contractorExisist.item === 'cleaner' || contractorExisist.item === 'helper' || contractorExisist.item === 'head') {
                
               const pp= await prisma.categories.create({
                    data: {
                        contractorId: contractorID,
                        menueId: categoryExisist?.menueId,
                        itemName: categoryExisist?.itemName,
                        comment: ''
                    }
                })

                console.log('pp', pp);
                
            } else {
                console.log('llllll ss');
                
            }
            
            
        }
        

        
        
        return SuccessResponse({
            msg: "updated successfully",
            res,
            statusCode: 200
        })
    } catch (error: any) {
        return ErrorResponse({
            msg: error.message,
            res,
            statusCode: 500
        })
    }
}

export default handler;