export const usersType = {
    "bookingclerk": "bookingclerk",
    "seniorclerk": "seniorclerk",
    "wageclerk": "wageclerk",
    "operationclerk": "operationclerk",
    "admin": "admin"
}


export const HEAD_CONST = "head"
export const CLEANER_CONST = "cleaner"