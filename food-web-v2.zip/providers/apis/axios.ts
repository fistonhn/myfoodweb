import Axios from "axios";

// export const axios = Axios.create({
//     baseURL: "http://localhost:3000/api"
// })

export const axios = Axios.create({
    baseURL: "https://myfoodweb.vercel.app/api/"
})